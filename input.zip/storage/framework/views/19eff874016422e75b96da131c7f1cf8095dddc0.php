<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('nit')); ?>

            <?php echo e(Form::text('nit', $empresa->nit, ['class' => 'form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'placeholder' => 'Nit'])); ?>

            <?php echo $errors->first('nit', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('nombre')); ?>

            <?php echo e(Form::text('nombre', $empresa->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('tipo_regimen')); ?>

            <?php echo e(Form::text('tipo_regimen', $empresa->tipo_regimen, ['class' => 'form-control' . ($errors->has('tipo_regimen') ? ' is-invalid' : ''), 'placeholder' => 'Tipo Regimen'])); ?>

            <?php echo $errors->first('tipo_regimen', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('NRegimen')); ?>

            <?php echo e(Form::text('NRegimen', $empresa->NRegimen, ['class' => 'form-control' . ($errors->has('NRegimen') ? ' is-invalid' : ''), 'placeholder' => 'Nregimen'])); ?>

            <?php echo $errors->first('NRegimen', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Email')); ?>

            <?php echo e(Form::text('Email', $empresa->Email, ['class' => 'form-control' . ($errors->has('Email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('Email', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Direccion')); ?>

            <?php echo e(Form::text('Direccion', $empresa->Direccion, ['class' => 'form-control' . ($errors->has('Direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion'])); ?>

            <?php echo $errors->first('Direccion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Logo')); ?>

            <?php echo e(Form::text('Logo', $empresa->Logo, ['class' => 'form-control' . ($errors->has('Logo') ? ' is-invalid' : ''), 'placeholder' => 'Logo'])); ?>

            <?php echo $errors->first('Logo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Telefono')); ?>

            <?php echo e(Form::text('Telefono', $empresa->Telefono, ['class' => 'form-control' . ($errors->has('Telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

            <?php echo $errors->first('Telefono', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('NombreReprent')); ?>

            <?php echo e(Form::text('NombreReprent', $empresa->NombreReprent, ['class' => 'form-control' . ($errors->has('NombreReprent') ? ' is-invalid' : ''), 'placeholder' => 'Nombrereprent'])); ?>

            <?php echo $errors->first('NombreReprent', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('estado')); ?>

            <?php echo e(Form::text('estado', $empresa->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

            <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\resources\views/empresa/form.blade.php ENDPATH**/ ?>