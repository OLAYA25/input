<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('TipoMovimiento_id')); ?>

            <?php echo e(Form::text('TipoMovimiento_id', $movimiento->TipoMovimiento_id, ['class' => 'form-control' . ($errors->has('TipoMovimiento_id') ? ' is-invalid' : ''), 'placeholder' => 'Tipomovimiento Id'])); ?>

            <?php echo $errors->first('TipoMovimiento_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('OrigenBodega_id')); ?>

            <?php echo e(Form::text('OrigenBodega_id', $movimiento->OrigenBodega_id, ['class' => 'form-control' . ($errors->has('OrigenBodega_id') ? ' is-invalid' : ''), 'placeholder' => 'Origenbodega Id'])); ?>

            <?php echo $errors->first('OrigenBodega_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('OrigenProveedor_id')); ?>

            <?php echo e(Form::text('OrigenProveedor_id', $movimiento->OrigenProveedor_id, ['class' => 'form-control' . ($errors->has('OrigenProveedor_id') ? ' is-invalid' : ''), 'placeholder' => 'Origenproveedor Id'])); ?>

            <?php echo $errors->first('OrigenProveedor_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('UsuarioDestino_id')); ?>

            <?php echo e(Form::text('UsuarioDestino_id', $movimiento->UsuarioDestino_id, ['class' => 'form-control' . ($errors->has('UsuarioDestino_id') ? ' is-invalid' : ''), 'placeholder' => 'Usuariodestino Id'])); ?>

            <?php echo $errors->first('UsuarioDestino_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('DestinoBodega_id')); ?>

            <?php echo e(Form::text('DestinoBodega_id', $movimiento->DestinoBodega_id, ['class' => 'form-control' . ($errors->has('DestinoBodega_id') ? ' is-invalid' : ''), 'placeholder' => 'Destinobodega Id'])); ?>

            <?php echo $errors->first('DestinoBodega_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('users_id')); ?>

            <?php echo e(Form::text('users_id', $movimiento->users_id, ['class' => 'form-control' . ($errors->has('users_id') ? ' is-invalid' : ''), 'placeholder' => 'Users Id'])); ?>

            <?php echo $errors->first('users_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Caja_id')); ?>

            <?php echo e(Form::text('Caja_id', $movimiento->Caja_id, ['class' => 'form-control' . ($errors->has('Caja_id') ? ' is-invalid' : ''), 'placeholder' => 'Caja Id'])); ?>

            <?php echo $errors->first('Caja_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Cuenta_id')); ?>

            <?php echo e(Form::text('Cuenta_id', $movimiento->Cuenta_id, ['class' => 'form-control' . ($errors->has('Cuenta_id') ? ' is-invalid' : ''), 'placeholder' => 'Cuenta Id'])); ?>

            <?php echo $errors->first('Cuenta_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('ValorImpuesto')); ?>

            <?php echo e(Form::text('ValorImpuesto', $movimiento->ValorImpuesto, ['class' => 'form-control' . ($errors->has('ValorImpuesto') ? ' is-invalid' : ''), 'placeholder' => 'Valorimpuesto'])); ?>

            <?php echo $errors->first('ValorImpuesto', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('ValorSinImpuesto')); ?>

            <?php echo e(Form::text('ValorSinImpuesto', $movimiento->ValorSinImpuesto, ['class' => 'form-control' . ($errors->has('ValorSinImpuesto') ? ' is-invalid' : ''), 'placeholder' => 'Valorsinimpuesto'])); ?>

            <?php echo $errors->first('ValorSinImpuesto', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Total')); ?>

            <?php echo e(Form::text('Total', $movimiento->Total, ['class' => 'form-control' . ($errors->has('Total') ? ' is-invalid' : ''), 'placeholder' => 'Total'])); ?>

            <?php echo $errors->first('Total', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('estado')); ?>

            <?php echo e(Form::text('estado', $movimiento->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

            <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('update_at')); ?>

            <?php echo e(Form::text('update_at', $movimiento->update_at, ['class' => 'form-control' . ($errors->has('update_at') ? ' is-invalid' : ''), 'placeholder' => 'Update At'])); ?>

            <?php echo $errors->first('update_at', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/movimiento/form.blade.php ENDPATH**/ ?>