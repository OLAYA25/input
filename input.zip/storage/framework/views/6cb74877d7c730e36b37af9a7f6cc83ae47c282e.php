<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<div class="card-body">
<div class="table-responsive">
    <table id="demo-dt-basic" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead class="thead">
            <tr>
                <th>No</th>
                
                <th>Tipo persona</th>
                <th>Numero documento</th>
                <th>Razon social</th>
                <th>Regimen</th>
                <th>Tipo</th>
                <th>Correofacturacion</th>
                <th>Observacion</th>
                <th>Estado</th>

                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($proveedore->id ?? null); ?></td>
                    
                    <td><?php echo e($proveedore->TipoPersona); ?></td>
                    <td><?php echo e($proveedore->NumeroDocumento); ?></td>
                    <td><?php echo e($proveedore->RazonSocial); ?></td>
                   
                    <td><?php echo e($proveedore->Regimen); ?></td>
                    <td><?php echo e($proveedore->Tipo); ?></td>
                    <td><?php echo e($proveedore->CorreoFacturacion); ?></td>
                    <td><?php echo e($proveedore->Observacion); ?></td>
                    <td><?php echo e($proveedore->estado); ?></td>

                    <td>
                        <form action="<?php echo e(route('proveedores.destroy',$proveedore->id)); ?>" method="POST">
                            <?php if(Route::is('usuariobasicos.edit') ): ?>
                                <a class="btn btn-sm btn-info " onclick="agregarusers('<?php echo e($usuariobasico->id); ?>','<?php echo e($proveedore->id); ?>')" href="#"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Agregar')); ?></a>
                            <?php endif; ?>
                            <?php if(Route::is('productos.edit') ): ?>
                                <a class="btn btn-sm btn-info " data-dismiss="modal" onclick="agregar('<?php echo e($proveedore->id); ?>')" href="#"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Agregar')); ?></a>
                            <script>
                                function agregar (id) {
                                    document.getElementById('Proveedor_id').value ="";
                                    document.getElementById('Proveedor_id').value = id;
                                }
                            </script>
                            <?php else: ?>
                            <a class="btn btn-sm btn-primary " href="<?php echo e(route('proveedores.show',$proveedore->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                            <a class="btn btn-sm btn-success" href="<?php echo e(route('proveedores.edit',$proveedore->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                            
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"  class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/proveedore/tabla.blade.php ENDPATH**/ ?>