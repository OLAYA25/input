
<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    <?php echo e(Form::label('Descripcion')); ?>

                    <?php echo e(Form::text('Descripcion', $caja->Descripcion, ['class' => 'form-control' . ($errors->has('Descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion'])); ?>

                    <?php echo $errors->first('Descripcion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <?php echo e(Form::label('estado')); ?>

                    <?php echo e(Form::select('estado',['Activo'=>'Activo','Inactivo'=>'Inactivo'], $caja->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

                    <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <?php echo e(Form::label('numero')); ?>

                    <?php echo e(Form::text('numero', $caja->numero, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Numero'])); ?>

                    <?php echo $errors->first('numero', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
        </div>
        
        
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\resources\views/caja/form.blade.php ENDPATH**/ ?>