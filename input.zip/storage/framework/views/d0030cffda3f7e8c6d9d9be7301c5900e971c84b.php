<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Nit')); ?>

            <?php echo e(Form::text('Nit', $empresa->Nit, ['class' => 'form-control' . ($errors->has('Nit') ? ' is-invalid' : ''), 'placeholder' => 'Nit'])); ?>

            <?php echo $errors->first('Nit', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nombre')); ?>

            <?php echo e(Form::text('Nombre', $empresa->Nombre, ['class' => 'form-control' . ($errors->has('Nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('Nombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Telefono')); ?>

            <?php echo e(Form::text('Telefono', $empresa->Telefono, ['class' => 'form-control' . ($errors->has('Telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

            <?php echo $errors->first('Telefono', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Email')); ?>

            <?php echo e(Form::text('Email', $empresa->Email, ['class' => 'form-control' . ($errors->has('Email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('Email', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Direccion')); ?>

            <?php echo e(Form::text('Direccion', $empresa->Direccion, ['class' => 'form-control' . ($errors->has('Direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion'])); ?>

            <?php echo $errors->first('Direccion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Logos')); ?>

            <?php echo e(Form::text('Logos', $empresa->Logos, ['class' => 'form-control' . ($errors->has('Logos') ? ' is-invalid' : ''), 'placeholder' => 'Logos'])); ?>

            <?php echo $errors->first('Logos', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LIBROS\CONTABILIDADJETXCEL\resources\views/empresa/form.blade.php ENDPATH**/ ?>