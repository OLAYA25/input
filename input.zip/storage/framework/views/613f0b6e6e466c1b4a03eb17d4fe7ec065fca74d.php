<?php $__env->startSection('template_title'); ?>
    <?php echo e(__('Update')); ?> Caja
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                <?php if ($__env->exists('partials.errors')) echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <div class="card card-default">
                    
                    <div class="card-header">
                        <h3 class="card-title"><?php echo e(__('Update')); ?> Caja</h3>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="panel-body">
                        <form method="POST" action="<?php echo e(route('cajas.update', $caja->id)); ?>"  role="form" enctype="multipart/form-data">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo csrf_field(); ?>

                            <?php echo $__env->make('caja.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </form>
                    </div>
                    <?php
                        use App\Models\Parametizarcaja;
                        $parametizarcaja = new Parametizarcaja();
                    ?>
                    <div class="card-header">
                        <h3 class="card-title"><?php echo e(__('Actualización ')); ?> parametizar cajas</h3>
                    </div>
                    <div class="panel-body">
                        <form method="POST" action="<?php echo e(route('parametizarcajas.store')); ?>"  role="form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <?php echo $__env->make('parametizarcaja.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                        </form>
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\resources\views/caja/edit.blade.php ENDPATH**/ ?>