<div class="table-responsive">
    <table id="demo-dt-basic" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead class="thead">
            <tr>
                <th>No</th>
                
                <th>Producto Id</th>
                <th>Impuesto Id</th>
                <th>Principal</th>
                <th>Valorbase</th>
                <th>Proveedor Id</th>
                <th>Valorpublico</th>
                <th>Descuento1</th>
                <th>Cantidad1</th>
                <th>Descuento2</th>
                <th>Cantidad2</th>
                <th>Descuento3</th>
                <th>Cantidad3</th>

                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $actualizarprecios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actualizarprecio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($actualizarprecio->id); ?></td>
                    
                    <td><?php echo e($actualizarprecio->producto->Descripcion ?? null); ?></td>
                    <td><?php echo e($actualizarprecio->Impuesto_id ?? null); ?></td>
                    <td><?php echo e($actualizarprecio->Principal); ?></td>
                    <td><?php echo e($actualizarprecio->ValorBase); ?></td>
                    <td><?php echo e($actualizarprecio->Proveedor_id); ?></td>
                    <td><?php echo e($actualizarprecio->ValorPublico); ?></td>
                    <td><?php echo e($actualizarprecio->Descuento1); ?></td>
                    <td><?php echo e($actualizarprecio->Cantidad1); ?></td>
                    <td><?php echo e($actualizarprecio->Descuento2); ?></td>
                    <td><?php echo e($actualizarprecio->Cantidad2); ?></td>
                    <td><?php echo e($actualizarprecio->Descuento3); ?></td>
                    <td><?php echo e($actualizarprecio->Cantidad3); ?></td>

                    <td>
                        <form action="<?php echo e(route('actualizarprecios.destroy',$actualizarprecio->id)); ?>" method="POST">
                            <a class="btn btn-sm btn-primary " href="<?php echo e(route('actualizarprecios.show',$actualizarprecio->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                            <a class="btn btn-sm btn-success" href="<?php echo e(route('actualizarprecios.edit',$actualizarprecio->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/actualizarprecio/tabla.blade.php ENDPATH**/ ?>