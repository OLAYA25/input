<table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Caja Id</th>
										<th>Bodegad Id</th>
										<th>Cuentas Id</th>
										<th>Estado</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $parametizarcajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parametizarcaja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($parametizarcaja->id); ?></td>
                                            
											<td><?php echo e($parametizarcaja->caja->Descripcion ?? null); ?></td>
											<td><?php echo e($parametizarcaja->bodega ->Descripcion ?? null); ?></td>
											<td><?php echo e($parametizarcaja->cuenta ->descripcion ?? null); ?></td>
											<td><?php echo e($parametizarcaja->estado); ?></td>

                                            <td>
                                                <?php if(Route::is('cajas.edit')): ?>
                                                <a class="btn btn-sm btn-primary " href="<?php echo e(route('parametizarcajas.show',$parametizarcaja->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                                <a class="btn btn-sm btn-success" href="<?php echo e(route('parametizarcajas.edit',$parametizarcaja->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                                                
                                                <?php else: ?>
                                                <form action="<?php echo e(route('parametizarcajas.destroy',$parametizarcaja->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('parametizarcajas.show',$parametizarcaja->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('parametizarcajas.edit',$parametizarcaja->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                                                </form>
                                                <?php endif; ?>
                                               
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table><?php /**PATH C:\xampp\htdocs\input\resources\views/parametizarcaja/tabla.blade.php ENDPATH**/ ?>