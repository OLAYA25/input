<?php
    $PAGE_NUM = $PAGE_NUM ?? 1;
    $PAGE_COUNT = $PAGE_COUNT ?? 1;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factura</title>
    <style>
        <?php if($size === 'carta'||$size === 'ofici' ): ?>
            @import  url('<?php echo e(asset('../resources/css/reportecarta.css')); ?>');
        <?php elseif($size === 'tirilla'): ?>
            @import  url('<?php echo e(asset('../resources/css/tirilla.css')); ?>');
        <?php endif; ?>

    </style>
</head>
<body>
    
    <div style="text-align: right; font-size: 10px; margin-bottom: 10px;">
        Página <?php echo e($PAGE_NUM); ?> de <?php echo e($PAGE_COUNT); ?>

    </div>
    <div class="row">
        <div class="col-sm-4 logo" >
            <img src="<?php echo e(asset('../storage/app/public/logos/' . basename($movimiento->caja->empresas->Logo ?? ''))); ?>" alt="Logo" style="max-width: 100px; max-height: 100px;">
        </div>
        <div class="col-sm-4">
            <div class="company-info">
                <div class="company-name"><?php echo e($movimiento->caja->empresas->nombre ?? null); ?></div>
                <div class="company-details">
                    NIT: <?php echo e($movimiento->caja->empresas->nit ?? null); ?><br>
                    Dirección: <?php echo e($movimiento->caja->empresas->Direccion ?? null); ?><br>
                    TEL: <?php echo e($movimiento->caja->empresas->Telefono ?? null); ?><br> 
                    Email: <?php echo e($movimiento->caja->empresas->Email ?? null); ?><br> 
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <!-- Aquí va el código QR -->
            <div class="company-name"">
            <div class="additional-info" style="text-align: center;">
                <?php
                    $url = request()->url();
                    try {
                        $qrcode = DNS2D::getBarcodeHTML($url, 'QRCODE', 2, 2);
                    } catch (\Exception $e) {
                        $qrcode = 'Error al generar el código QR: ' . $e->getMessage();
                    }
                ?>
                <div style="text-align: center;">
                    <div style="display: inline-block; width: 80px; height: 80px; ">
                        <?php echo $qrcode; ?>

                    </div>
                 </div>
                 <?php echo e($movimiento->movimientosbasico->Descripcion . " " .$movimiento->movimientosbasico->Codigo  ."0000". $movimiento->id ?? NULL); ?>

            </div>

        
            </div>
        </div>
        
    </div>
    
   
    <div class="additional-info">
        
            
    </div>
    <table class="customer-info">
        
        <tr class ="customer-info-label" >
            
            <td>   <span class="customer-info-label">Cliente:</span>
            <?php if($movimiento->usuariobasico): ?>
            <?php echo e(($movimiento->usuariobasico->Apellido1 ?? '') . ' ' . 
               ($movimiento->usuariobasico->Apeelido2 ?? '') . ' ' . 
               ($movimiento->usuariobasico->Nombre1 ?? '') . ' ' . 
               ($movimiento->usuariobasico->Nombre2 ?? '')); ?>

            <?php else: ?>
            N/A
        <?php endif; ?>
            </td>

            <td > <strong>NIT:</strong> <?php echo e($movimiento->usuariobasico->NDocumento  ?? ' '); ?>   </td>
        </tr>
        <tr >
            <td><span class="customer-info-label">Dirección:</span>
            <span><?php echo e($movimiento->usuariobasico->Direccion ?? null); ?></span></td>
            <td><span class="customer-info-label">Tipo de Operación:</span>
            <span> <?php echo e($movimiento->movimientosbasico->Descripcion ?? " "); ?></span> </td>
        </tr>
        <tr >
            <td><span class="customer-info-label">Teléfono:</span>
            <span><?php echo e($movimiento->usuariobasico->Telefono?? " "); ?></span></td>
            <td ><span class="customer-info-label">Fecha de Facturación:</span>
            <span><?php echo e($movimiento->updated_at ?? " "); ?></span></td>
        </tr>
        <tr >
            <td><span class="customer-info-label">Forma de pago: <?php echo e($movimiento->metodoPago." " ?? null); ?></span>
            </td>
            <td ><span class="customer-info-label">Fecha de Vencimiento:</span>
            <span><?php echo e($movimiento->updated_at ?? " "); ?></span></td>
        </tr>
        <tr >
            <td><span class="customer-info-label">Medio de pago:</span>
            <span><?php echo e($movimiento->medioPago." " ?? null); ?></span></td>
            <td ></td>
        </tr>
    </table>


    <table class="products-table">
    <?php if($size === 'carta'): ?>
        <tr>
            <th>Ítem</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Cantidad</th>
            <th>Total</th>
        </tr>
        <?php $__currentLoopData = $movimiento->movimientosdatallados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($productos->productos->Descripcion.' '); ?>  <?php echo e($productos->Obervacion); ?></td>
            <td><?php echo e($productos->Valor_Unitario); ?></td>
            <td><?php echo e($productos->Cantidad_Ingreso); ?></td>
            <td><?php echo e($productos->TotalValor); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if($size === 'tirilla'): ?>
        <tr>
            <th>id</th>
            <th>Descripción</th>
           
            <th>Can</th>
            <th>Total</th>
        </tr>
        <?php $__currentLoopData = $movimiento->movimientosdatallados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($productos->productos->Descripcion.' '); ?>  <?php echo e($productos->Obervacion); ?></td>
            
            <td><?php echo e($productos->Cantidad_Ingreso); ?></td>
            <td><?php echo e($productos->TotalValor); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
    <div class="company-name" style="font-weight: bold; text-align: center; margin-top: 20px; margin-bottom: 20px;">
    <storage> DETALLE IMPUESTOS</storage> 
    </div>
    <table class="total-section">
    <tr>
        <th>TIPO</th>
        <th>BASE/IMP</th>
        <th>IMP</th>
        <th>COMPRA</th>
    </tr>
    <tr class="total-row">
    <td></td> 
        <td class="amount">$ <?php echo e(number_format($movimiento->ValorSinImpuesto, 2, '.', ',')); ?></td>
        <td class="amount">$ <?php echo e(number_format($movimiento->ValorImpuesto, 2, '.', ',')); ?></td>
        <td class="amount">$ <?php echo e(number_format($movimiento->Total, 2, '.', ',')); ?></td>
    </tr>
    <tr class="total-row total">
        <td>TOTAL</td>
        <td class="amount">$ <?php echo e(number_format($movimiento->ValorSinImpuesto, 2, '.', ',')); ?></td>
        <td class="amount">$ <?php echo e(number_format($movimiento->ValorImpuesto, 2, '.', ',')); ?></td>
        <td class="amount">$ <?php echo e(number_format($movimiento->Total, 2, '.', ',')); ?></td>
    </tr>
    <tr class="total-a-pagar">
        <td colspan="3"><strong>TOTAL A PAGAR:</strong></td>
        <td class="amount">$ <?php echo e(number_format($movimiento->Total, 2, '.', ',')); ?></td>
    </tr>
</table>

    
</div>

    <div class="terms " >
        <h3><?php echo e($movimiento->movimientosbasico->TituloPiePagina ?? NULL); ?></h3>
        <ul style="font-size: 10px; padding-left: 20px;">
        <?php echo e($movimiento->movimientosbasico->PiePagina ?? NULL); ?></ul>
    </div>
</body>
<?php if($size === 'tirilla'): ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
            // Ajustar el ancho de las columnas
            var table = document.querySelector('.products-table');
            table.style.tableLayout = 'fixed';
            
            var cols = table.querySelectorAll('th, td');
            cols.forEach(function(col, index) {
                if (index % 4 === 0) col.style.width = '10%'; // Ítem
                if (index % 4 === 1) col.style.width = '15%'; // Cantidad
                if (index % 4 === 2) col.style.width = '55%'; // Descripción
                if (index % 4 === 3) col.style.width = '20%'; // Total
            });

            window.print();
    </script>
<?php endif; ?>

</html>
<?php /**PATH C:\xampp\htdocs\input\input\resources\views/movimientos/facturas.blade.php ENDPATH**/ ?>