
<?php
$bancos = App\Models\Banco::where('estado', 'Activo')->pluck('nombre', 'id');
?>
<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('bancos_id', 'Banco')); ?>

                    <?php echo e(Form::select('bancos_id', $bancos ?? [], $cuenta->bancos_id, ['class' => 'form-control' . ($errors->has('bancos_id') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione un banco'])); ?>

                    <?php echo $errors->first('bancos_id', '<div class="invalid-feedback">:message</div>'); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('descripcion', 'Descripción')); ?>

                    <?php echo e(Form::text('descripcion', $cuenta->descripcion, ['class' => 'form-control' . ($errors->has('descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese una descripción'])); ?>

                    <?php echo $errors->first('descripcion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('tipo', 'Tipo de cuenta')); ?>

                    <?php echo e(Form::select('tipo', ['Corriente' => 'Corriente', 'Ahorros' => 'Ahorros','Efectivo' =>'Efectivo'], $cuenta->tipo, ['class' => 'form-control' . ($errors->has('tipo') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione el tipo de cuenta'])); ?>

                    <?php echo $errors->first('tipo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('numero', 'Número de cuenta')); ?>

                    <?php echo e(Form::text('numero', $cuenta->numero, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese el número de cuenta'])); ?>

                    <?php echo $errors->first('numero', '<div class="invalid-feedback">:message</div>'); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('estado', 'Estado')); ?>

                    <?php echo e(Form::select('estado', ['Activo' => 'Activo', 'Inactivo' => 'Inactivo'], $cuenta->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione el estado'])); ?>

                    <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
        <a href="<?php echo e(route('cajas.create')); ?>" class="btn btn-success">Siguiente</a>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/cuenta/form.blade.php ENDPATH**/ ?>