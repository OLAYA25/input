<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('estado')); ?>

            <?php echo e(Form::text('estado', $codigo->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

            <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Codigo')); ?>

            <?php echo e(Form::text('Codigo', $codigo->Codigo, ['class' => 'form-control' . ($errors->has('Codigo') ? ' is-invalid' : ''), 'placeholder' => 'Codigo'])); ?>

            <?php echo $errors->first('Codigo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Subcodigo')); ?>

            <?php echo e(Form::text('Subcodigo', $codigo->Subcodigo, ['class' => 'form-control' . ($errors->has('Subcodigo') ? ' is-invalid' : ''), 'placeholder' => 'Subcodigo'])); ?>

            <?php echo $errors->first('Subcodigo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Descipcion')); ?>

            <?php echo e(Form::text('Descipcion', $codigo->Descipcion, ['class' => 'form-control' . ($errors->has('Descipcion') ? ' is-invalid' : ''), 'placeholder' => 'Descipcion'])); ?>

            <?php echo $errors->first('Descipcion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\resources\views/codigo/form.blade.php ENDPATH**/ ?>