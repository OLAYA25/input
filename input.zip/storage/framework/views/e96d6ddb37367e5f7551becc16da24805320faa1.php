<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <?php if(Route::is('movimientosbasicos.edit')): ?>
            
            
            
                <div class="form-group">
                
                    <?php echo e(Form::text('Movimientos_id', $movimientosbasico->id, ['class' => 'form-control' . ($errors->has('Movimientos_id') ? ' is-invalid' : ''), 'placeholder' => 'ID Movimientos', 'style'=>'Display:none'])); ?>

                    <?php echo $errors->first('Movimientos_id', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
        
            <?php endif; ?>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('Prefijo')); ?>

                    <?php echo e(Form::text('Prefijo', $resolucione->Prefijo, ['class' => 'form-control' . ($errors->has('Prefijo') ? ' is-invalid' : ''), 'placeholder' => 'Prefijo'])); ?>

                    <?php echo $errors->first('Prefijo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('estado', 'Estado')); ?>

                    <?php echo e(Form::select('estado', ['Activo' => 'Activo', 'Inactivo' => 'Inactivo'], $resolucione->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione'])); ?>

                    <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo e(Form::label('DesdeNumero', 'Desde')); ?>

                    <?php echo e(Form::number('DesdeNumero', $resolucione->DesdeNumero, ['class' => 'form-control' . ($errors->has('DesdeNumero') ? ' is-invalid' : ''), 'placeholder' => 'Desde'])); ?>

                    <?php echo $errors->first('DesdeNumero', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo e(Form::label('HastaNumero', 'Hasta')); ?>

                    <?php echo e(Form::number('HastaNumero', $resolucione->HastaNumero, ['class' => 'form-control' . ($errors->has('HastaNumero') ? ' is-invalid' : ''), 'placeholder' => 'Hasta'])); ?>

                    <?php echo $errors->first('HastaNumero', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo e(Form::label('FechaInicio', 'Inicio')); ?>

                    <?php echo e(Form::date('FechaInicio', $resolucione->FechaInicio, ['class' => 'form-control' . ($errors->has('FechaInicio') ? ' is-invalid' : ''), 'placeholder' => 'Inicio'])); ?>

                    <?php echo $errors->first('FechaInicio', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <?php echo e(Form::label('FechaFin', 'Fin')); ?>

                    <?php echo e(Form::date('FechaFin', $resolucione->FechaFin, ['class' => 'form-control' . ($errors->has('FechaFin') ? ' is-invalid' : ''), 'placeholder' => 'Fin'])); ?>

                    <?php echo $errors->first('FechaFin', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
        </div>

        <div class="form-group">
            <?php echo e(Form::label('Vigencia')); ?>

            <?php echo e(Form::number('Vigencia', $resolucione->Vigencia, ['class' => 'form-control' . ($errors->has('Vigencia') ? ' is-invalid' : ''), 'placeholder' => 'Vigencia'])); ?>

            <?php echo $errors->first('Vigencia', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <?php echo e(Form::hidden('updated_at', now())); ?>

    </div>
    
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Enviar</button>
        
        <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-success">Siguiente</a>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/resolucione/form.blade.php ENDPATH**/ ?>