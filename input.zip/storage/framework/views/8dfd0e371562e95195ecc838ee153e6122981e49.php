<div class="table-responsive">
   <table class="table table-striped table-hover">
    <thead class="thead">
        <tr>
            <th>No</th>
            
            <th>Descripcion</th>
            <th>Productos Id</th>
            <th>Impuestos Id</th>
            <th>Valor</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $impuestosProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impuestosProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($impuestosProducto->id); ?></td>
                
                <td><?php echo e($impuestosProducto->Descripcion); ?></td>
                <td><?php echo e($impuestosProducto->producto->Descripcion ?? NULL); ?></td>
                <td><?php echo e($impuestosProducto->impuesto->Descripcion ?? NULL); ?></td>
                <td><?php echo e($impuestosProducto->impuesto->Valor ?? NULL); ?></td>
                <td>
                    <form action="<?php echo e(route('impuestos-productos.destroy',$impuestosProducto->id)); ?>" method="POST">
                        <a class="btn btn-sm btn-primary " href="<?php echo e(route('impuestos-productos.show',$impuestosProducto->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                        <a class="btn btn-sm btn-success" href="<?php echo e(route('impuestos-productos.edit',$impuestosProducto->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/impuestos-producto/table.blade.php ENDPATH**/ ?>