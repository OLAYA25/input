<?php $__env->startSection('template_title'); ?>
    <?php echo e($codigo->name ?? "{{ __('Show') Codigo"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Codigo</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('codigos.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e($codigo->estado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Codigo:</strong>
                            <?php echo e($codigo->Codigo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Subcodigo:</strong>
                            <?php echo e($codigo->Subcodigo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Descipcion:</strong>
                            <?php echo e($codigo->Descipcion); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\input\resources\views/codigo/show.blade.php ENDPATH**/ ?>