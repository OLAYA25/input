
<?php
$empresas = App\Models\Empresa::where('estado', 'Activo')->pluck('nombre', 'id');
$bodega = App\Models\Bodega::where('estado', 'Activo')->pluck('Descripcion', 'id');
$usuario = App\Models\Usuariobasico::where('estado', 'Activo')->pluck('Nombre1', 'id');
$cuenta= App\Models\Cuenta::where('estado', 'Activo')->pluck('descripcion', 'id');
?>

<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('Descripcion')); ?>

                    <?php echo e(Form::text('Descripcion', $caja->Descripcion, ['class' => 'form-control' . ($errors->has('Descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion'])); ?>

                    <?php echo $errors->first('Descripcion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('estado')); ?>

                    <?php echo e(Form::select('estado',['Activo'=>'Activo','Inactivo'=>'Inactivo'], $caja->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

                    <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('numero')); ?>

                    <?php echo e(Form::text('numero', $caja->numero, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Numero'])); ?>

                    <?php echo $errors->first('numero', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('Empresa')); ?>

                    <?php echo e(Form::select('Empresas_id', $empresas,$caja->Empresas_id, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Empresas'])); ?>

                    <?php echo $errors->first('Empresas_id', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('Cuenta Defecto Entrada')); ?>

                    <?php echo e(Form::select('CuentaDefectoIngreso', $cuenta,$caja->CuentaDefectoIngreso, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Cuenta Defecto'])); ?>

                    <?php echo $errors->first('CajaDefecto', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('Cuenta Defecto Salida')); ?>

                    <?php echo e(Form::select('CuentaDefectoSalida', $cuenta,$caja->CuentaDefectoSalida, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Caja Defecto Salida'])); ?>

                    <?php echo $errors->first('CajaDefectoSalida', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <?php echo e(Form::label('Usuario Defecto')); ?>

                    <?php echo e(Form::select('UsuarioDefecto', $usuario,$caja->UsuarioDefecto, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Usuario Defecto'])); ?>

                    <?php echo $errors->first('UsuarioDefecto', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <?php echo e(Form::label('Origen Bodega Defecto')); ?>

                    <?php echo e(Form::select('OrigenBodegaDefecto', $bodega,$caja->OrigenBodegaDefecto, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Origen Bodega Defecto'])); ?>

                    <?php echo $errors->first('OrigenBodegaDefecto', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <?php echo e(Form::label('Destino Bodega Defecto')); ?>

                    <?php echo e(Form::select('DestinoBodegaDefecto', $bodega,$caja->DestinoBodegaDefecto, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Destino Bodega Defecto'])); ?>

                    <?php echo $errors->first('DestinoBodegaDefecto', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>

        </div>
        
        
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/caja/form.blade.php ENDPATH**/ ?>