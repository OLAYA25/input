<?php $__env->startSection('template_title'); ?>
    Producto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Producto')); ?>

                            </span>

                             <div class="float-right">
                                <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  <?php echo e(__('Create New')); ?>

                                </a>
                              </div>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="demo-dt-basic" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Descripcion</th>
										<th>Imagen</th>
										<th>Estado</th>
										<th>Existencias</th>
										<th>Stock Max</th>
										<th>Stock Min</th>
										<th>Vendernegativos</th>
										<th>Descinventario</th>
										<th>Numeroserial</th>
										<th>Talla</th>
										<th>Largor</th>
										<th>Alto</th>
										<th>Ancho</th>
										<th>Observaciones</th>
										<th>Familia1 Id</th>
										<th>Familia2 Id</th>
										<th>Familia3 Id</th>
										<th>Unidadmedida Id</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            
											<td><?php echo e($producto->Descripcion); ?></td>
											<td><?php echo e($producto->Imagen); ?></td>
											<td><?php echo e($producto->Estado); ?></td>
											<td><?php echo e($producto->Existencias); ?></td>
											<td><?php echo e($producto->Stock_Max); ?></td>
											<td><?php echo e($producto->Stock_Min); ?></td>
											<td><?php echo e($producto->VenderNegativos); ?></td>
											<td><?php echo e($producto->DescInventario); ?></td>
											<td><?php echo e($producto->NumeroSerial); ?></td>
											<td><?php echo e($producto->Talla); ?></td>
											<td><?php echo e($producto->Largor); ?></td>
											<td><?php echo e($producto->Alto); ?></td>
											<td><?php echo e($producto->Ancho); ?></td>
											<td><?php echo e($producto->Observaciones); ?></td>
											<td><?php echo e($producto->familia1_id); ?></td>
											<td><?php echo e($producto->familia2_id); ?></td>
											<td><?php echo e($producto->familia3_id); ?></td>
											<td><?php echo e($producto->unidadmedida_id); ?></td>

                                            <td>
                                                <form action="<?php echo e(route('productos.destroy',$producto->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('productos.show',$producto->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('productos.edit',$producto->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $productos->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\input\resources\views/producto/index.blade.php ENDPATH**/ ?>