<?php $__env->startSection('template_title'); ?>
    Usuariobasico
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Usuariobasico')); ?>

                            </span>

                             <div class="float-right">
                                <a href="<?php echo e(route('usuariobasicos.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  <?php echo e(__('Create New')); ?>

                                </a>
                              </div>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="demo-dt-basic" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Tipodocumento</th>
										<th>Ndocumento</th>
										<th>Nombre1</th>
										<th>Nombre2</th>
										<th>Apellido1</th>
										<th>Apeelido2</th>
										<th>Telefono</th>
										<th>Email</th>
										<th>Checkproveedor</th>
										<th>Estado</th>
										<th>Fechanacimiento</th>
										<th>Genero</th>
										<th>Telefonofijo</th>
										<th>Telefonomovil</th>
										<th>Sexo</th>
										<th>Empleado Id</th>
										<th>Proveedor Id</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $usuariobasicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuariobasico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            
											<td><?php echo e($usuariobasico->TipoDocumento); ?></td>
											<td><?php echo e($usuariobasico->NDocumento); ?></td>
											<td><?php echo e($usuariobasico->Nombre1); ?></td>
											<td><?php echo e($usuariobasico->Nombre2); ?></td>
											<td><?php echo e($usuariobasico->Apellido1); ?></td>
											<td><?php echo e($usuariobasico->Apeelido2); ?></td>
											<td><?php echo e($usuariobasico->Telefono); ?></td>
											<td><?php echo e($usuariobasico->Email); ?></td>
											<td><?php echo e($usuariobasico->Checkproveedor); ?></td>
											<td><?php echo e($usuariobasico->estado); ?></td>
											<td><?php echo e($usuariobasico->FechaNacimiento); ?></td>
											<td><?php echo e($usuariobasico->Genero); ?></td>
											<td><?php echo e($usuariobasico->TelefonoFijo); ?></td>
											<td><?php echo e($usuariobasico->TelefonoMovil); ?></td>
											<td><?php echo e($usuariobasico->Sexo); ?></td>
											<td><?php echo e($usuariobasico->Empleado_id); ?></td>
											<td><?php echo e($usuariobasico->Proveedor_id); ?></td>

                                            <td>
                                                <form action="<?php echo e(route('usuariobasicos.destroy',$usuariobasico->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('usuariobasicos.show',$usuariobasico->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('usuariobasicos.edit',$usuariobasico->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $usuariobasicos->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\input\resources\views/usuariobasico/index.blade.php ENDPATH**/ ?>