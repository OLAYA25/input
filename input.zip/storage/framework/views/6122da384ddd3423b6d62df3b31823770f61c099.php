<?php
    use App\Models\Banco;
    $bancos= Banco ::where('estado','Activo') -> pluck("nombre","id");
?>
<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('bancos')); ?>

            <?php echo e(Form::select('bancos_id', $bancos,$cuenta->bancos_id, ['class' => 'form-control' . ($errors->has('bancos_id') ? ' is-invalid' : ''), 'placeholder' => 'Bancos'])); ?>

            <?php echo $errors->first('bancos_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('descripcion')); ?>

            <?php echo e(Form::text('descripcion', $cuenta->descripcion, ['class' => 'form-control' . ($errors->has('descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion'])); ?>

            <?php echo $errors->first('descripcion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('tipo')); ?>

            <?php echo e(Form::select('tipo', ['Efectivo'=>'Efectivo','Corriente'=>'Corriente','Ahorro'=>'Ahorro'],$cuenta->tipo, ['class' => 'form-control' . ($errors->has('tipo') ? ' is-invalid' : ''), 'placeholder' => 'Tipo'])); ?>

            <?php echo $errors->first('tipo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('numero')); ?>

            <?php echo e(Form::text('numero', $cuenta->numero, ['class' => 'form-control' . ($errors->has('numero') ? ' is-invalid' : ''), 'placeholder' => 'Numero'])); ?>

            <?php echo $errors->first('numero', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('estado')); ?>

            <?php echo e(Form::select('estado', ['Activo'=>'Activo','Inactivo'=>'Inactivo'],$cuenta->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

           <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\resources\views/cuenta/form.blade.php ENDPATH**/ ?>