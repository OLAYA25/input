<table class="table table-striped table-hover">
    <thead class="thead">
        <tr>
            <th>No</th>
            
            <th>Descripcion</th>
            <th>Estado</th>
            <th>Cantidad</th>
            <th>Producto Id</th>

            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $codigoalternos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigoalterno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($codigoalterno->id); ?></td>
                
                <td><?php echo e($codigoalterno->Descripcion); ?></td>
                <td><?php echo e($codigoalterno->estado); ?></td>
                <td><?php echo e($codigoalterno->cantidad); ?></td>
                <td><?php echo e($codigoalterno->producto_id); ?></td>.

                <td>
                    <form action="<?php echo e(route('codigoalternos.destroy',$codigoalterno->id)); ?>" method="POST">
                        <a class="btn btn-sm btn-primary " href="<?php echo e(route('codigoalternos.show',$codigoalterno->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                        <a class="btn btn-sm btn-success" href="<?php echo e(route('codigoalternos.edit',$codigoalterno->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\input\input\resources\views/Codigoalterno/tabla.blade.php ENDPATH**/ ?>