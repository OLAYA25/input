<table class="table table-striped table-hover">
    <thead class="thead">
        <tr>
            <th>No</th>
            
            <th>Estado</th>
            <th>Codigo</th>
            <th>Subcodigo</th>
            <th>Descipcion</th>

            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $codigos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                
                <td><?php echo e($codigo->estado); ?></td>
                <td><?php echo e($codigo->Codigo); ?></td>
                <td><?php echo e($codigo->Subcodigo); ?></td>
                <td><?php echo e($codigo->Descipcion); ?></td>

                <td>
                    <form action="<?php echo e(route('codigos.destroy',$codigo->id)); ?>" method="POST">
                        <a class="btn btn-sm btn-primary " href="<?php echo e(route('codigos.show',$codigo->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                        <a class="btn btn-sm btn-success" href="<?php echo e(route('codigos.edit',$codigo->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\input\resources\views/codigo/tabla.blade.php ENDPATH**/ ?>