<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <div class="col-sm-4">
            <div class="form-group">
            <?php echo e(Form::label('id_empresa')); ?>

            <?php echo e(Form::select('id_empresa', $empresa,$caja->id_empresa, ['class' => 'form-control' . ($errors->has('id_empresa') ? ' is-invalid' : ''), 'placeholder' => 'Id Empresa'])); ?>

            <?php echo $errors->first('id_empresa', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
            </div>

            <div class="col-sm-4">
            <div class="form-group">
            <?php echo e(Form::label('Nombre de Caja')); ?>

            <?php echo e(Form::text('Descripcion', $caja->Descripcion, ['class' => 'form-control' . ($errors->has('Descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion'])); ?>

            <?php echo $errors->first('Descripcion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
            </div>

            <div class="col-sm-4">
            <div class="form-group">
            <?php echo e(Form::label('Estado')); ?>

            <?php echo e(Form::select('Estado',['Activo'=>'Activo','Inactivo'=>'Inactivo'], $caja->Estado, ['class' => 'form-control' . ($errors->has('Estado') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

            <?php echo $errors->first('Estado', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
            </div>
        

        </div>
    
        

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LIBROS\CONTABILIDADJETXCEL\resources\views/caja/form.blade.php ENDPATH**/ ?>