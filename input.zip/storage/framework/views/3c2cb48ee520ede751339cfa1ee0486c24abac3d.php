<?php $__env->startSection('template_title'); ?>
    <?php echo e($producto->name ?? "{{ __('Show') Producto"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Producto</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('productos.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            <?php echo e($producto->Descripcion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Imagen:</strong>
                            <?php echo e($producto->Imagen); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e($producto->Estado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Existencias:</strong>
                            <?php echo e($producto->Existencias); ?>

                        </div>
                        <div class="form-group">
                            <strong>Stock Max:</strong>
                            <?php echo e($producto->Stock_Max); ?>

                        </div>
                        <div class="form-group">
                            <strong>Stock Min:</strong>
                            <?php echo e($producto->Stock_Min); ?>

                        </div>
                        <div class="form-group">
                            <strong>Vendernegativos:</strong>
                            <?php echo e($producto->VenderNegativos); ?>

                        </div>
                        <div class="form-group">
                            <strong>Descinventario:</strong>
                            <?php echo e($producto->DescInventario); ?>

                        </div>
                        <div class="form-group">
                            <strong>Numeroserial:</strong>
                            <?php echo e($producto->NumeroSerial); ?>

                        </div>
                        <div class="form-group">
                            <strong>Talla:</strong>
                            <?php echo e($producto->Talla); ?>

                        </div>
                        <div class="form-group">
                            <strong>Largor:</strong>
                            <?php echo e($producto->Largor); ?>

                        </div>
                        <div class="form-group">
                            <strong>Alto:</strong>
                            <?php echo e($producto->Alto); ?>

                        </div>
                        <div class="form-group">
                            <strong>Ancho:</strong>
                            <?php echo e($producto->Ancho); ?>

                        </div>
                        <div class="form-group">
                            <strong>Observaciones:</strong>
                            <?php echo e($producto->Observaciones); ?>

                        </div>
                        <div class="form-group">
                            <strong>Familia1 Id:</strong>
                            <?php echo e($producto->familia1_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Familia2 Id:</strong>
                            <?php echo e($producto->familia2_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Familia3 Id:</strong>
                            <?php echo e($producto->familia3_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Unidadmedida Id:</strong>
                            <?php echo e($producto->unidadmedida_id); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\resources\views/producto/show.blade.php ENDPATH**/ ?>