<div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Descripcion</th>
										<th>Valor</th>
										<th>Fechavigencia</th>
										<th>Estado</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $impuestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impuesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($impuesto->id); ?></td>
                                            
											<td><?php echo e($impuesto->Descripcion); ?></td>
											<td><?php echo e($impuesto->Valor); ?></td>
											<td><?php echo e($impuesto->FechaVigencia); ?></td>
											<td><?php echo e($impuesto->estado); ?></td>

                                            <td>
                                                <?php if(Route::is('impuestos.index')): ?>
                                                <form action="<?php echo e(route('impuestos.destroy',$impuesto->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('impuestos.show',$impuesto->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('impuestos.edit',$impuesto->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                                                </form>
                                                <?php else: ?>
                                                <a class="btn btn-sm btn-primary " data-dismiss="modal"  onclick="AgregarImpuestos(<?php echo e($producto->id); ?>,<?php echo e($impuesto->id); ?>)" href="#"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Aceptar')); ?></a>
                                                    
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <script>
                            function AgregarImpuestos(idProducto, impuestos_id) {
                                fetch('<?php echo e(route("impuestos-productos.store")); ?>', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Accept': 'application/json',
                                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                                    },
                                    body: JSON.stringify({
                                        productos_id: idProducto,
                                        impuestos_id: impuestos_id
                                    })
                                })
                                .then(response => response.json())
                                .then(data => {
                                    
                                    document.getElementById('modalImpuestos').style.display = 'none';
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    alert('Hubo un error al agregar el impuesto');
                                });
                            }
                        </script><?php /**PATH C:\xampp\htdocs\input\input\resources\views/impuesto/table.blade.php ENDPATH**/ ?>