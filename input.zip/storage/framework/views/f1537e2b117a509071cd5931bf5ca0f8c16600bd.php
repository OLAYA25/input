<div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Movimientos Id</th>
										<th>Prefijo</th>
										<th>Desdenumero</th>
										<th>Hastanumero</th>
										<th>Fechainicio</th>
										<th>Fechafin</th>
										<th>Vigencia</th>
										<th>Upated At</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $resoluciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resolucione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($resolucione->id); ?></td>
                                            
											<td><?php echo e($resolucione->Movimientos_id); ?></td>
											<td><?php echo e($resolucione->Prefijo); ?></td>
											<td><?php echo e($resolucione->DesdeNumero); ?></td>
											<td><?php echo e($resolucione->HastaNumero); ?></td>
											<td><?php echo e($resolucione->FechaInicio); ?></td>
											<td><?php echo e($resolucione->FechaFin); ?></td>
											<td><?php echo e($resolucione->Vigencia); ?></td>
											<td><?php echo e($resolucione->estado); ?></td>

                                            <td>
                                                <form action="<?php echo e(route('resoluciones.destroy',$resolucione->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('resoluciones.show',$resolucione->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('resoluciones.edit',$resolucione->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/resolucione/table.blade.php ENDPATH**/ ?>