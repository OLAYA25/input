<?php $__env->startSection('template_title'); ?>
    <?php echo e(__('Update')); ?> Usuariobasico
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                <?php if ($__env->exists('partials.errors')) echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card card-default">
                    <div class="card-header">
                        <span class="card-title"><?php echo e(__('Update')); ?> Usuariobasico</span>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <div class="panel-body">
                    <style>
                        /* Custom styles for the tabs */
                        .nav-tabs .nav-link {
                            border: 1px solid transparent;
                            border-top-left-radius: .25rem;
                            border-top-right-radius: .25rem;
                            transition: all 0.3s ease;
                        }
                        .nav-tabs .nav-link:hover {
                            background-color: #f8f9fa;
                            border-color: #dee2e6 #dee2e6 #fff;
                        }
                        .nav-tabs .nav-link.active {
                            color: #495057;
                            background-color: #fff;
                            border-color: #dee2e6 #dee2e6 #fff;
                        }
                        .nav-tabs .nav-link.disabled {
                            color: #6c757d;
                        }
                    </style>
                    
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" id="Usuarios-tab" href="#Usuarios" aria-selected="true">Usuarios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="Proveedores-tab" href="#Proveedores" aria-selected="false">Proveedores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="Empleados-tab" href="#Empleados" aria-selected="false">Empleados</a>
                        </li>
                    </ul>
                    <div class="tab-content mt-3">
                        <div class="tab-pane active" id="Usuarios" role="tabpanel" aria-labelledby="Usuarios-tab">
                            <form method="POST" action="<?php echo e(route('usuariobasicos.update', $usuariobasico->id)); ?>"  role="form" enctype="multipart/form-data">
                                <?php echo e(method_field('PATCH')); ?>

                                <?php echo csrf_field(); ?>
                
                                <?php echo $__env->make('usuariobasico.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                            </form>
                        </div>
                        <div class="tab-pane" id="Proveedores" role="tabpanel" aria-labelledby="Proveedores-tab">
                            <?php echo $__env->make('proveedore.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php
                            use App\Models\Proveedore;
                                $proveedores = Proveedore::paginate();
                            ?>
                            <?php echo $__env->make('proveedore.tabla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="tab-pane" id="Empleados" role="tabpanel" aria-labelledby="Empleados-tab">
                            Contenido de Empleados
                        </div>
                    </div>
                    
                    
                </div>
                
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\resources\views/usuariobasico/edit.blade.php ENDPATH**/ ?>