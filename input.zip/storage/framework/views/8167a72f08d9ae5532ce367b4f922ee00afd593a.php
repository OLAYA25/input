<style>
    /* Estilo para el cuadro de firma */
    .signature-box {
        border: 2px dashed #ccc;
        min-height: 150px;
        /* Altura mínima del cuadro de firma */
        max-width: 100%;
        /* Ancho máximo del cuadro de firma */
        max-height: 200px;
        /* Altura máxima del cuadro de firma */
        overflow: hidden;
        /* Ocultar partes de la imagen que se desborden */
        margin-bottom: 10px;
        position: relative;
        /* Añade una posición relativa para ajustar la imagen */
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* Estilo para la imagen dentro del cuadro de firma */
    .signature-box img {
        max-width: 100%;
        /* Ancho máximo de la imagen */
        max-height: 100%;
        /* Altura máxima de la imagen */
        display: block;
        /* Eliminar espacios en blanco alrededor de la imagen */
    }
</style>

<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <!-- Datos Básicos -->
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <?php echo e(Form::label('Descripcion')); ?>

                            <?php echo e(Form::text('Descripcion', $producto->Descripcion, ['class' => 'form-control' .
                            ($errors->has('Descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion'])); ?>

                            <?php echo $errors->first('Descripcion', '<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <?php echo e(Form::label('Referencia')); ?>

                            <?php echo e(Form::text('NumeroSerial', $producto->NumeroSerial, ['class' => 'form-control' .
                            ($errors->has('NumeroSerial') ? ' is-invalid' : ''), 'placeholder' => 'Numeroserial'])); ?>

                            <?php echo $errors->first('NumeroSerial', '<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <?php echo e(Form::label('Estado')); ?>

                            <?php echo e(Form::select('Estado', ['Activo'=>'Activo','Inactivo'=>'Inactivo'],$producto->Estado,
                            ['class' => 'form-control' . ($errors->has('Estado') ? ' is-invalid' : ''), 'placeholder' =>
                            'Estado'])); ?>

                            <?php echo $errors->first('Estado', '<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <?php echo e(Form::label('Imagen')); ?>

                            <?php echo e(Form::file('Imagen', ['class' => 'signature-box' . ($errors->has('Imagen') ? '
                            is-invalid' : ''), 'placeholder' => 'Imagen'])); ?>

                            <?php echo $errors->first('Imagen', '<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <?php echo e(Form::label('familia1_id')); ?>

                            <?php echo e(Form::text('familia1_id', $producto->familia1_id, ['class' => 'form-control' .
                            ($errors->has('familia2_id') ? ' is-invalid' : ''), 'placeholder' => 'Familia1 Id'])); ?>

                            <?php echo $errors->first('familia1_id', '<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <?php echo e(Form::label('familia3_id')); ?>

                            <?php echo e(Form::text('familia3_id', $producto->familia3_id, ['class' => 'form-control' .
                            ($errors->has('familia2_id') ? ' is-invalid' : ''), 'placeholder' => 'Familia3 Id'])); ?>

                            <?php echo $errors->first('familia3_id', '<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <?php echo e(Form::label('familia2_id')); ?>

                            <?php echo e(Form::text('familia2_id', $producto->familia2_id, ['class' => 'form-control' .
                            ($errors->has('familia2_id') ? ' is-invalid' : ''), 'placeholder' => 'Familia2 Id'])); ?>

                            <?php echo $errors->first('familia2_id', '<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <!-- Tabs para Datos Detallados -->
                <ul class="nav nav-tabs" id="productDetailsTabs" role="tablist">
                    
                    <li class="nav-item">
                        <a class="nav-link" id="details-tab" data-toggle="tab" href="#details" role="tab"
                            aria-controls="details" aria-selected="false">Detalles</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="packages-tab" data-toggle="tab" href="#packages" role="tab"
                            aria-controls="packages" aria-selected="false">Paquetes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="warehouse-tab" data-toggle="tab" href="#warehouse" role="tab"
                            aria-controls="warehouse" aria-selected="false">Almacen</a>
                    </li>
                  
                </ul>

                <div class="tab-content" id="productDetailsTabsContent">
                    <div class="tab-pane fade" id="warehouse" role="tabpanel" aria-labelledby="warehouse-tab">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('VenderNegativos')); ?>

                                    <?php echo e(Form::text('VenderNegativos', $producto->VenderNegativos, ['class' =>
                                    'form-control' . ($errors->has('VenderNegativos') ? ' is-invalid' : ''),
                                    'placeholder' => 'Vendernegativos'])); ?>

                                    <?php echo $errors->first('VenderNegativos', '<div class="invalid-feedback">:message</div>
                                    '); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('DescInventario')); ?>

                                    <?php echo e(Form::text('DescInventario', $producto->DescInventario, ['class' =>
                                    'form-control' . ($errors->has('DescInventario') ? ' is-invalid' : ''),
                                    'placeholder' => 'Descinventario'])); ?>

                                    <?php echo $errors->first('DescInventario', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('Existencias')); ?>

                                    <?php echo e(Form::text('Existencias', $producto->Existencias, ['class' => 'form-control' .
                                    ($errors->has('Existencias') ? ' is-invalid' : ''), 'placeholder' => 'Existencias'])); ?>

                                    <?php echo $errors->first('Existencias', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('Stock_Max')); ?>

                                    <?php echo e(Form::text('Stock_Max', $producto->Stock_Max, ['class' => 'form-control' .
                                    ($errors->has('Stock_Max') ? ' is-invalid' : ''), 'placeholder' => 'Stock Max'])); ?>

                                    <?php echo $errors->first('Stock_Max', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('Stock_Min')); ?>

                                    <?php echo e(Form::text('Stock_Min', $producto->Stock_Min, ['class' => 'form-control' .
                                    ($errors->has('Stock_Min') ? ' is-invalid' : ''), 'placeholder' => 'Stock Min'])); ?>

                                    <?php echo $errors->first('Stock_Min', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                            </div>
                        </div>
                        <!-- More warehouse fields as needed -->
                    </div>
                  

                <!-- Detalles Tab -->
                <div class="tab-pane fade" id="details" role="tabpanel" aria-labelledby="details-tab">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo e(Form::label('Talla')); ?>

                                <?php echo e(Form::text('Talla', $producto->Talla, ['class' => 'form-control' .
                                ($errors->has('Talla') ? ' is-invalid' : ''), 'placeholder' => 'Talla'])); ?>

                                <?php echo $errors->first('Talla', '<div class="invalid-feedback">:message</div>'); ?>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo e(Form::label('Largor')); ?>

                                <?php echo e(Form::text('Largor', $producto->Largor, ['class' => 'form-control' .
                                ($errors->has('Largor') ? ' is-invalid' : ''), 'placeholder' => 'Largor'])); ?>

                                <?php echo $errors->first('Largor', '<div class="invalid-feedback">:message</div>'); ?>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo e(Form::label('Alto')); ?>

                                <?php echo e(Form::text('Alto', $producto->Alto, ['class' => 'form-control' .
                                ($errors->has('Alto') ? ' is-invalid' : ''), 'placeholder' => 'Alto'])); ?>

                                <?php echo $errors->first('Alto', '<div class="invalid-feedback">:message</div>'); ?>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo e(Form::label('Ancho')); ?>

                                <?php echo e(Form::text('Ancho', $producto->Ancho, ['class' => 'form-control' .
                                ($errors->has('Ancho') ? ' is-invalid' : ''), 'placeholder' => 'Ancho'])); ?>

                                <?php echo $errors->first('Ancho', '<div class="invalid-feedback">:message</div>'); ?>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e(Form::label('Observaciones')); ?>

                                <?php echo e(Form::text('Observaciones', $producto->Observaciones, ['class' => 'form-control' .
                                ($errors->has('Observaciones') ? ' is-invalid' : ''), 'placeholder' => 'Observaciones'])); ?>

                                <?php echo $errors->first('Observaciones', '<div class="invalid-feedback">:message</div>'); ?>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e(Form::label('unidadmedida_id')); ?>

                                <?php echo e(Form::text('unidadmedida_id', $producto->unidadmedida_id, ['class' => 'form-control'
                                . ($errors->has('unidadmedida_id') ? ' is-invalid' : ''), 'placeholder' => 'Unidadmedida
                                Id'])); ?>

                                <?php echo $errors->first('unidadmedida_id', '<div class="invalid-feedback">:message</div>'); ?>

                            </div>
                        </div>
                    </div>
                    <!-- More detail fields as needed -->
                </div>



                <!-- Paquetes Tab -->
                <div class="tab-pane fade" id="packages" role="tabpanel" aria-labelledby="packages-tab">
                    <!-- Package-related fields go here -->
                </div>

                <!-- Almacen Tab -->

                <!-- Seriales Tab -->
                <div class="tab-pane fade" id="serials" role="tabpanel" aria-labelledby="serials-tab">
                    <!-- Serial-related fields go here -->
                </div>
                
                <!-- Impuestos Tab -->
                <div class="tab-pane fade" id="taxes" role="tabpanel" aria-labelledby="taxes-tab">
                    <!-- Tax-related fields go here -->
                </div>



            
                
            </div>

        </div>

    </div>
   
</div>
<div class="box-footer mt20">
    <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
</div>
</div>
 <br>
<!-- jQuery and Bootstrap scripts for enabling tabs -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>


    document.addEventListener('DOMContentLoaded', function () {
  
       
       
    $(document).ready(function () {
        $('#productDetailsTabs a').on('click', function (e) {
            e.preventDefault();
            
            });
        }); 
    });
</script><?php /**PATH C:\xampp\htdocs\input\resources\views/producto/form.blade.php ENDPATH**/ ?>