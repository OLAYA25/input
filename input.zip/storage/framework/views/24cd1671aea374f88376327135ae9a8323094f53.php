<?php $__env->startSection('template_title'); ?>
    <?php echo e($movimientosdatallado->name ?? "{{ __('Show') Movimientosdatallado"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Movimientosdatallado</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('movimientosdatallados.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Movimientos Id:</strong>
                            <?php echo e($movimientosdatallado->Movimientos_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Producto Id:</strong>
                            <?php echo e($movimientosdatallado->Producto_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Cantidad Ingreso:</strong>
                            <?php echo e($movimientosdatallado->Cantidad_Ingreso); ?>

                        </div>
                        <div class="form-group">
                            <strong>Valorunitario:</strong>
                            <?php echo e($movimientosdatallado->ValorUnitario); ?>

                        </div>
                        <div class="form-group">
                            <strong>Totalvalor:</strong>
                            <?php echo e($movimientosdatallado->TotalValor); ?>

                        </div>
                        <div class="form-group">
                            <strong>Impuesto Id:</strong>
                            <?php echo e($movimientosdatallado->Impuesto_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Cantidad Egreso:</strong>
                            <?php echo e($movimientosdatallado->Cantidad_Egreso); ?>

                        </div>
                        <div class="form-group">
                            <strong>Valor Unitario:</strong>
                            <?php echo e($movimientosdatallado->Valor_Unitario); ?>

                        </div>
                        <div class="form-group">
                            <strong>Users Id:</strong>
                            <?php echo e($movimientosdatallado->users_id); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\input\resources\views/movimientosdatallado/show.blade.php ENDPATH**/ ?>