<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('categorias')); ?>

            <?php echo e(Form::text('categorias', $categoria->categorias, ['class' => 'form-control' . ($errors->has('categorias') ? ' is-invalid' : ''), 'placeholder' => 'Categorias'])); ?>

            <?php echo $errors->first('categorias', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LIBROS\resources\views/categoria/form.blade.php ENDPATH**/ ?>