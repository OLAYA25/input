<?php $__env->startSection('template_title'); ?>
    <?php echo e($usuariobasico->name ?? "{{ __('Show') Usuariobasico"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Usuariobasico</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('usuariobasicos.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Tipodocumento:</strong>
                            <?php echo e($usuariobasico->TipoDocumento); ?>

                        </div>
                        <div class="form-group">
                            <strong>Ndocumento:</strong>
                            <?php echo e($usuariobasico->NDocumento); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre1:</strong>
                            <?php echo e($usuariobasico->Nombre1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre2:</strong>
                            <?php echo e($usuariobasico->Nombre2); ?>

                        </div>
                        <div class="form-group">
                            <strong>Apellido1:</strong>
                            <?php echo e($usuariobasico->Apellido1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Apeelido2:</strong>
                            <?php echo e($usuariobasico->Apeelido2); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            <?php echo e($usuariobasico->Telefono); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email:</strong>
                            <?php echo e($usuariobasico->Email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Checkproveedor:</strong>
                            <?php echo e($usuariobasico->Checkproveedor); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e($usuariobasico->estado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Fechanacimiento:</strong>
                            <?php echo e($usuariobasico->FechaNacimiento); ?>

                        </div>
                        <div class="form-group">
                            <strong>Genero:</strong>
                            <?php echo e($usuariobasico->Genero); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefonofijo:</strong>
                            <?php echo e($usuariobasico->TelefonoFijo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefonomovil:</strong>
                            <?php echo e($usuariobasico->TelefonoMovil); ?>

                        </div>
                        <div class="form-group">
                            <strong>Sexo:</strong>
                            <?php echo e($usuariobasico->Sexo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Empleado Id:</strong>
                            <?php echo e($usuariobasico->Empleado_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Proveedor Id:</strong>
                            <?php echo e($usuariobasico->Proveedor_id); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\resources\views/usuariobasico/show.blade.php ENDPATH**/ ?>