<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('nit', 'NIT')); ?>

                    <?php echo e(Form::text('nit', $empresa->nit, ['class' => 'form-control' . ($errors->has('nit') ? ' is-invalid' : ''), 'placeholder' => 'NIT'])); ?>

                    <?php echo $errors->first('nit', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                
                <div class="form-group">
                    <?php echo e(Form::label('nombre', 'Nombre')); ?>

                    <?php echo e(Form::text('nombre', $empresa->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

                    <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                
                <div class="form-group">
                    <?php echo e(Form::label('tipo_regimen', 'Tipo de Régimen')); ?>

                    <?php echo e(Form::select('tipo_regimen', [
                        'Natural' => 'Natural',
                        'Régimen Común' => 'Régimen Común',
                        'Régimen Simplificado' => 'Régimen Simplificado',
                        'Gran Contribuyente' => 'Gran Contribuyente',
                        'Régimen Especial' => 'Régimen Especial',
                        'No Responsable de IVA' => 'No Responsable de IVA'
                    ], $empresa->tipo_regimen, ['class' => 'form-control' . ($errors->has('tipo_regimen') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione el tipo de régimen'])); ?>

                    <?php echo $errors->first('tipo_regimen', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                
                <div class="form-group">
                    <?php echo e(Form::label('NRegimen', 'Número de Régimen')); ?>

                    <?php echo e(Form::text('NRegimen', $empresa->NRegimen, ['class' => 'form-control' . ($errors->has('NRegimen') ? ' is-invalid' : ''), 'placeholder' => 'Número de Régimen'])); ?>

                    <?php echo $errors->first('NRegimen', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                
                <div class="form-group">
                    <?php echo e(Form::label('Email', 'Correo Electrónico')); ?>

                    <?php echo e(Form::email('Email', $empresa->Email, ['class' => 'form-control' . ($errors->has('Email') ? ' is-invalid' : ''), 'placeholder' => 'Correo Electrónico'])); ?>

                    <?php echo $errors->first('Email', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('Direccion', 'Dirección')); ?>

                    <?php echo e(Form::text('Direccion', $empresa->Direccion, ['class' => 'form-control' . ($errors->has('Direccion') ? ' is-invalid' : ''), 'placeholder' => 'Dirección'])); ?>

                    <?php echo $errors->first('Direccion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                
                <div class="form-group">
                    <?php echo e(Form::label('Logo', 'Logo')); ?>

                    <?php echo e(Form::file('Logo', ['class' => 'form-control-file' . ($errors->has('Logo') ? ' is-invalid' : ''), 'accept' => 'image/*'])); ?>

                    <?php if($empresa->Logo): ?>
                        <img src="<?php echo e(asset('storage/' . $empresa->Logo)); ?>" alt="Logo actual" class="mt-2" style="max-width: 200px;">
                    <?php endif; ?>
                    <?php echo $errors->first('Logo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                
                <div class="form-group">
                    <?php echo e(Form::label('Telefono', 'Teléfono')); ?>

                    <?php echo e(Form::text('Telefono', $empresa->Telefono, ['class' => 'form-control' . ($errors->has('Telefono') ? ' is-invalid' : ''), 'placeholder' => 'Teléfono'])); ?>

                    <?php echo $errors->first('Telefono', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                
                <div class="form-group">
                    <?php echo e(Form::label('NombreReprent', 'Nombre del Representante')); ?>

                    <?php echo e(Form::text('NombreReprent', $empresa->NombreReprent, ['class' => 'form-control' . ($errors->has('NombreReprent') ? ' is-invalid' : ''), 'placeholder' => 'Nombre del Representante'])); ?>

                    <?php echo $errors->first('NombreReprent', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                
                <div class="form-group">
                    <?php echo e(Form::label('estado', 'Estado')); ?>

                    <?php echo e(Form::select('estado', ['Activo'=>'Activo','Inactivo'=>'Inactivo'], $empresa->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione el estado'])); ?>

                    <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>   <a href="<?php echo e(route('usuariobasicos.create')); ?>" class="btn btn-success"><?php echo e(__('Siguiente')); ?></a>
    </div>
   
</div><?php /**PATH C:\xampp\htdocs\input\input\resources\views/empresa/form.blade.php ENDPATH**/ ?>