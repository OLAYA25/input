<?php $__env->startSection('template_title'); ?>
    <?php echo e($movimientosbasico->name ?? "{{ __('Show') Movimientosbasico"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Movimientosbasico</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('movimientosbasicos.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Codigo:</strong>
                            <?php echo e($movimientosbasico->Codigo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            <?php echo e($movimientosbasico->Descripcion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Descuento:</strong>
                            <?php echo e($movimientosbasico->Descuento); ?>

                        </div>
                        <div class="form-group">
                            <strong>Agregar:</strong>
                            <?php echo e($movimientosbasico->Agregar); ?>

                        </div>
                        <div class="form-group">
                            <strong>Alerta:</strong>
                            <?php echo e($movimientosbasico->Alerta); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\input\resources\views/movimientosbasico/show.blade.php ENDPATH**/ ?>