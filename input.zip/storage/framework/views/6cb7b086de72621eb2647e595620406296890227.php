<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Descripcion')); ?>

            <?php echo e(Form::text('Descripcion', $bodega->Descripcion, ['class' => 'form-control' . ($errors->has('Descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion'])); ?>

            <?php echo $errors->first('Descripcion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <?php
             $Empresa = App\Models\Empresa::pluck('nombre','id');
        ?>
       
        <div class="form-group">
            <?php echo e(Form::label('empresa')); ?>

            <?php echo e(Form::select('empresa', $Empresa, $bodega->empresas, ['class' => 'form-control' . ($errors->has('empresa') ? ' is-invalid' : ''), 'placeholder' => 'Empresa'])); ?>

            <?php echo $errors->first('empresa', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('estado')); ?>

            <?php echo e(Form::text('estado', $bodega->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

            <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\resources\views/bodega/form.blade.php ENDPATH**/ ?>