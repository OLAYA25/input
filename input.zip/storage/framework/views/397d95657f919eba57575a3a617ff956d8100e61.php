<?php $__env->startSection('template_title'); ?>
    <?php echo e($empresa->name ?? "{{ __('Show') Empresa"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Empresa</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('empresas.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nit:</strong>
                            <?php echo e($empresa->nit); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($empresa->nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Tipo Regimen:</strong>
                            <?php echo e($empresa->tipo_regimen); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nregimen:</strong>
                            <?php echo e($empresa->NRegimen); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email:</strong>
                            <?php echo e($empresa->Email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Direccion:</strong>
                            <?php echo e($empresa->Direccion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Logo:</strong>
                            <?php echo e($empresa->Logo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            <?php echo e($empresa->Telefono); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombrereprent:</strong>
                            <?php echo e($empresa->NombreReprent); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e($empresa->estado); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\resources\views/empresa/show.blade.php ENDPATH**/ ?>