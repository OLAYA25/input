<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('Descripcion')); ?>

                    <?php echo e(Form::text('Descripcion', $codigoalterno->Descripcion, ['class' => 'form-control' . ($errors->has('Descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion'])); ?>

                    <?php echo $errors->first('Descripcion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('estado')); ?>

                    <?php echo e(Form::select('estado', ['Activo'=>'Activo','Inactivo'=>'Inactivo'],$codigoalterno->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : '')])); ?>

                    <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('cantidad')); ?>

                    <div class="input-group mar-btn ">
                        <?php echo e(Form::number('cantidad', $codigoalterno->cantidad, ['class' => 'form-control' . ($errors->has('cantidad') ? ' is-invalid' : ''), 'placeholder' => 'Cantidad'])); ?>

                        <span class="input-group-btn">
                            <a href="#" data-toggle="modal" id="Buscar"
                                    data-target=".bd-user-modal-lg" class="btn btn-success">Buscar </a>
                        </span>
                        <?php echo $errors->first('cantidad', '<div class="invalid-feedback">:message</div>'); ?>

                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo e(Form::label('producto_id')); ?>

                    <?php echo e(Form::text('producto_id', $codigoalterno->producto_id, ['class' => 'form-control' . ($errors->has('producto_id') ? ' is-invalid' : ''), 'placeholder' => 'Producto Id'])); ?>

                    <?php echo $errors->first('producto_id', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            
            
           
            
        </div>
        

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\input\resources\views/codigoalterno/form.blade.php ENDPATH**/ ?>