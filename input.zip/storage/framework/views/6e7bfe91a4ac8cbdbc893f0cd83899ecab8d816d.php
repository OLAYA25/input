<?php $__env->startSection('template_title'); ?>
    Movimiento
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Movimiento')); ?>

                            </span>

                             <div class="float-right">
                                <a href="<?php echo e(route('movimientos.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  <?php echo e(__('Create New')); ?>

                                </a>
                              </div>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Tipomovimiento Id</th>
										<th>Origenbodega Id</th>
										<th>Origenproveedor Id</th>
										<th>Usuariodestino Id</th>
										<th>Destinobodega Id</th>
										<th>Users Id</th>
										<th>Caja Id</th>
										<th>Cuenta Id</th>
										<th>Valorimpuesto</th>
										<th>Valorsinimpuesto</th>
										<th>Total</th>
										<th>Estado</th>
										<th>Update At</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            
											<td><?php echo e($movimiento->TipoMovimiento_id); ?></td>
											<td><?php echo e($movimiento->OrigenBodega_id); ?></td>
											<td><?php echo e($movimiento->OrigenProveedor_id); ?></td>
											<td><?php echo e($movimiento->UsuarioDestino_id); ?></td>
											<td><?php echo e($movimiento->DestinoBodega_id); ?></td>
											<td><?php echo e($movimiento->users_id); ?></td>
											<td><?php echo e($movimiento->Caja_id); ?></td>
											<td><?php echo e($movimiento->Cuenta_id); ?></td>
											<td><?php echo e($movimiento->ValorImpuesto); ?></td>
											<td><?php echo e($movimiento->ValorSinImpuesto); ?></td>
											<td><?php echo e($movimiento->Total); ?></td>
											<td><?php echo e($movimiento->estado); ?></td>
											<td><?php echo e($movimiento->update_at); ?></td>

                                            <td>
                                                <form action="<?php echo e(route('movimientos.destroy',$movimiento->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('movimientos.show',$movimiento->id)); ?>"><i class="fa fa-fw fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('movimientos.edit',$movimiento->id)); ?>"><i class="fa fa-fw fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> <?php echo e(__('Delete')); ?></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $movimientos->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\input\input\resources\views/movimiento/index.blade.php ENDPATH**/ ?>