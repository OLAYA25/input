// resources/js/app.js

// Configurar Laravel Echo con el broadcaster por defecto (Pusher)
import Echo from 'laravel-echo';

window.Pusher = require('pusher-js');

