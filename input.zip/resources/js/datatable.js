datatable(document).ready(function () {
    // Inicializar DataTable para tuTabla
    var table = datatable('table').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5'
        ]
    });






});